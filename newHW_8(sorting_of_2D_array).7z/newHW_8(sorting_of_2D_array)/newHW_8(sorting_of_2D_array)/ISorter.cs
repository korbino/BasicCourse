﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newHW_8_sorting_of_2D_array_
{
    interface ISorter
    {
        int[] Sort(int[] array, bool isSortingFromMinToMax);        
    }
}
